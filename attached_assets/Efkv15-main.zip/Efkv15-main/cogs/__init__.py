"""
Cogs Package

This package contains all cogs for the Discord bot.
"""

# Leave this file empty to make the directory a package