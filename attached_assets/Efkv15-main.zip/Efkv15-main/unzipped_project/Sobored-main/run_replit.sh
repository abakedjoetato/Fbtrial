#!/bin/bash
# Simple entry point for running the Discord bot via Replit
echo "Starting Discord bot..."
python start_discord_bot.py