"""
Discord extension namespace for compatibility with discord.py and py-cord

This package provides compatibility with discord.ext modules.
"""

# This is intentionally empty as the actual modules will be imported from their own files