#!/bin/bash

echo "Starting Discord bot..."

# Use our bootstrap script to properly set up the Python environment
echo "Using bootstrap script for proper path setup"
python bootstrap.py