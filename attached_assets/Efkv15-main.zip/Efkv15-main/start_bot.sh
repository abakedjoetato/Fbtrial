#!/bin/bash

# Start the Discord bot
echo "Starting Discord bot..."

# Make sure packages are installed
pip install -r requirements.txt

# Run the bot
python main.py